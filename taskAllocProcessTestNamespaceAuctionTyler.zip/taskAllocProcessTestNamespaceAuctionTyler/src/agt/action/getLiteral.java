// Internal action code for project taskAllocProcess_multiLevel

package action;

import jason.*;
import jason.asSemantics.*;
import jason.asSyntax.*;

public class getLiteral extends DefaultInternalAction {

    /**
	 * 
	 */
	private static final long serialVersionUID = -5813263010001744087L;

	int n;
	
	@Override
    public Object execute(TransitionSystem ts, Unifier un, Term[] args) throws Exception {
        // execute the internal action
//        ts.getAg().getLogger().info("executing internal action 'jia.getLiteral'");
//        if (true) { // just to show how to throw another kind of exception
//            throw new JasonException("not implemented!");
//        }

		ListTerm all = new ListTermImpl();
    
		ListTerm ids = (ListTerm) args[0];
		n=ids.size();
	
		for (Term term : ids) {
			String candidate = term.toString();
			//System.out.println("candidate:"+candidate);
			String part1 = candidate.substring(1,candidate.length()-1);
			//System.out.println("part1:"+part1);
			//String part2 = part1.substring(0,candidate.length()-1);
		    all.append(Literal.parseLiteral("literal("+part1+")"));
		    //all.append(Literal.parseLiteral("agNames("+candidate+")"));
		}
		
		return un.unifies(args[1], all);
        // everything ok, so returns true
        //return true;
    }
}
