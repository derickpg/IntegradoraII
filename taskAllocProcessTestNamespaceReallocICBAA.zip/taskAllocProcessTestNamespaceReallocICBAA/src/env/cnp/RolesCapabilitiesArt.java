package cnp;

import cartago.Artifact;
import cartago.OPERATION;
import jason.asSyntax.Literal;

import static jason.asSyntax.ASSyntax.*;

public class RolesCapabilitiesArt extends Artifact {
private int roleId;

void init(){
roleId = 0;
//this.defineObsProperty("rolesCapabilitiesStatus", "ok");
}

//@OPERATION void announceRoleCapability(String roleDescr, String capability){
@OPERATION void announceRoleCapability(String roleDescr, String capability){
	roleId++;	
	try {
		Literal lroleDescr = createLiteral(roleDescr); 
		Literal lcapability = createLiteral(capability);
		this.defineObsProperty("roleCapability",lroleDescr, lcapability);
	} catch (Exception ex){
	failed("announce_failed");
	}
}


//@OPERATION void completeTaskAnnounce(){
//	//String artifactName = "cnp_board_"+taskId;
//	this.updateObsProperty("blackboardStatus", "ready");
//}



//@OPERATION void clear(String id){
//	String artifactName = "cnp_board_"+taskId;
//	this.removeObsPropertyByTemplate("task", null, artifactName);
//}

}