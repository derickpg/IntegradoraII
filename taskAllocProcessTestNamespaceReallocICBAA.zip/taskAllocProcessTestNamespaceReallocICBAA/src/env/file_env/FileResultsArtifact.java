package file_env;
import jason.asSyntax.Atom;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;

import cartago.*;

public class FileResultsArtifact extends Artifact {
	
//	String currentWinner = "no_winner";
    ArrayList<String> results = new ArrayList<String>();
    int lineResults=1;

	
    @OPERATION public void init()  {
        // observable properties   
        defineObsProperty("running",     false);
        defineObsProperty("task",        "no_task");
        defineObsProperty("best_bid",    Double.MAX_VALUE);
  //      defineObsProperty("winner",      new Atom(currentWinner)); // Atom is a Jason type      
    }

    @OPERATION public void start(String task)  {
//    	if (getObsProperty("running").booleanValue())
//    		failed("The protocol is already running and so you cannot start it!");
//    	
//        getObsProperty("running").updateValue(true);
//        getObsProperty("task").updateValue(task);
    }
    
    @OPERATION public void addToFile(String line)  {
    	results.add(line);
    }
    
    
    @OPERATION public void saveFile()  {
    	saveToFile(results);    	
    }

    @OPERATION public void saveFile2(String finishResults)  {
    	saveToFile2(finishResults);
    }
    
    public void saveToFile(ArrayList<String> toF) {

    	File file;
    	FileWriter fileWritter;
    	BufferedWriter bufferWritter;
    	String fileName = "ResultTestData.txt";
    	//String fileName = "Results"+new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new java.util.Date()) +".txt";

    	try{
    		file =new File(fileName);
    		
    		//if file doesnt exists, then create it
    		if(!file.exists())
    			file.createNewFile();
    		
    		//true = append file - sem o true - new file
    		fileWritter = new FileWriter(file.getName());
    		//FileWriter fileWritter = new FileWriter(file.getName(),true);
    	    bufferWritter = new BufferedWriter(fileWritter);

        	
        	Iterator it = toF.iterator();
        	while (it.hasNext()) {
        		String line=(String)it.next();
        		System.out.println("GRAVAR:"+line);
        	
    	        bufferWritter.write(line);
        	    bufferWritter.newLine();
        	}
    	
        	bufferWritter.flush();
    	    bufferWritter.close();
    	    
    	}catch(IOException e){
    		e.printStackTrace();
    	}
    	    System.out.println("File done!");
    }//end saveToFile

public void saveToFile2(String results) {

    	File file;
    	FileWriter fileWritter;
    	BufferedWriter bufferWritter;
    	String fileName = "JacamoResults.txt";

    	try{
    		file =new File(fileName);
    		
    		//if file doesnt exists, then create it
    		if(!file.exists())
    			file.createNewFile();
    		
    		//true = append file - sem o true - new file
    		//fileWritter = new FileWriter(file.getName());
    		fileWritter = new FileWriter(file.getName(),true);
    	    bufferWritter = new BufferedWriter(fileWritter);

        		System.out.println("GRAVAR:"+results);
    	        bufferWritter.write(results);
        	    bufferWritter.newLine();
    	
        	bufferWritter.flush();
    	    bufferWritter.close();
    	    
    	}catch(IOException e){
    		e.printStackTrace();
    	}
    	    System.out.println("File done!");
    }//end saveToFile


}
