// Internal action code for project taskAllocProcess_multiLevel

package action;

import jason.*;
import jason.asSemantics.*;
import jason.asSyntax.*;
import jason.stdlib.term2string;

public class concactData extends DefaultInternalAction {

    
	private static final long serialVersionUID = 8103851073344184813L;

	
	@Override
    public Object execute(TransitionSystem ts, Unifier un, Term[] args) throws Exception {

    	String str1=args[0].toString();
    	String str2=args[1].toString();
    	String str3=args[2].toString();
    	String strConcatenated=str1+str2+str3;
    	
        ListTerm all = new ListTermImpl();
	    
	    all.append(Literal.parseLiteral("concatenated("+strConcatenated+")"));
	    return un.unifies(args[3], all);
	    //return true;
    }
}
