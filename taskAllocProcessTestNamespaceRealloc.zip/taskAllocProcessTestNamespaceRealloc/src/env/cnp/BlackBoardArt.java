package cnp;

import static jason.asSyntax.ASSyntax.createLiteral;

import cartago.Artifact;
import cartago.OPERATION;
import jason.asSyntax.Literal;
import jason.asSyntax.Term;

public class BlackBoardArt extends Artifact {
private int taskId;

void init(){
taskId = 0;
this.defineObsProperty("blackboardStatus", "working","");
}

@OPERATION void announce(String job, String subTaskDescr, String TaskDescr, String TaskType, String roleDescr){
	taskId++;
	try {
		Literal lJob = createLiteral(job);
		Literal lsubTaskDescr = createLiteral(subTaskDescr); 
		Literal lTaskDescr = createLiteral(TaskDescr);
		Literal lTaskType = createLiteral(TaskType);
		Literal lroleDescr = createLiteral(roleDescr);
		
		this.defineObsProperty("subTask", lsubTaskDescr, lTaskDescr, lTaskType, lroleDescr, lJob);
	} catch (Exception ex){
	failed("announce_failed");
	}
}

@OPERATION void completeTaskAnnounce(String job){
	//String artifactName = "cnp_board_"+taskId;
	Literal lJob = createLiteral(job);
	this.updateObsProperty("blackboardStatus", "ready", lJob);
}



//@OPERATION void clear(String id){
//	String artifactName = "cnp_board_"+taskId;
//	this.removeObsPropertyByTemplate("task", null, artifactName);
//}

}